<?php
session_start();

// if user is logged in → go to dashboard
if (isset($_SESSION["student_id"])) {
    header("Location: dashboard/dashboard.php");
    exit();
}

// otherwise → go to login
header("Location: auth/login.php");
exit();
?>