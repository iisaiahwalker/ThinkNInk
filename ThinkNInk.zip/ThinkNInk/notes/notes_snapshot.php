<?php
session_start();
if (!isset($_SESSION["student_id"])) {
    header("Location: ../auth/login.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>View Note</title>
    <link rel="stylesheet" href="../notes/editor.css">
</head>

<body>

<div class="toolbar">
    <button onclick="goBack()">⬅ Back</button>
</div>

<div id="canvas"></div>

<script>
const note_id = new URLSearchParams(window.location.search).get("note_id");
const course_id = new URLSearchParams(window.location.search).get("course_id");

/* ---------------- BACK BUTTON (FIXED & SAFE) ---------------- */
function goBack() {
    // Always return to shared tab safely
    if (course_id) {
        window.location.href = `/ThinkNInk/classes/classes.php?course_id=${course_id}&tab=shared`;
    } else {
        window.location.href = `/ThinkNInk/classes/classes.php?tab=shared`;
    }
}
</script>

<script>
let doc = null;

/* ---------------- LOAD NOTE ---------------- */
async function loadNote() {
    try {
        const res = await fetch(`/ThinkNInk/api/notes/get.php?id=${note_id}`);
        const data = await res.json();

        if (data?.content) {
            doc = JSON.parse(data.content);
            render();
        }
    } catch (err) {
        console.error("Failed to load note:", err);
    }
}

/* ---------------- RENDER SNAPSHOT ---------------- */
function render() {
    const canvas = document.getElementById("canvas");
    canvas.innerHTML = "";

    if (!doc) return;

    const page = doc.pages?.[doc.currentPage] || { elements: [] };

    page.elements.forEach(el => {
        const div = document.createElement("div");
        div.style.position = "absolute";
        div.style.left = el.x + "px";
        div.style.top = el.y + "px";

        /* TEXT */
        if (el.type === "text") {
            div.innerText = el.text;
            div.className = "textbox";
        }

        /* SHAPE */
        if (el.type === "shape") {
            div.style.width = el.w + "px";
            div.style.height = el.h + "px";
            div.style.background = "#b98aff";

            if (el.shape === "circle") {
                div.style.borderRadius = "50%";
            }

            if (el.shape === "triangle") {
                div.style.width = "0";
                div.style.height = "0";
                div.style.borderLeft = `${el.w / 2}px solid transparent`;
                div.style.borderRight = `${el.w / 2}px solid transparent`;
                div.style.borderBottom = `${el.h}px solid #b98aff`;
                div.style.background = "transparent";
            }
        }

        /* IMAGE */
        if (el.type === "image") {
            const img = document.createElement("img");
            img.src = el.src;
            img.style.width = el.w + "px";
            img.style.height = "auto";
            div.appendChild(img);
        }

        /* PEN */
        if (el.type === "pen") {
            const c = document.createElement("canvas");
            c.width = 2000;
            c.height = 2000;

            const ctx = c.getContext("2d");

            ctx.beginPath();
            el.path.forEach((p, i) => {
                if (i === 0) ctx.moveTo(p.x, p.y);
                else ctx.lineTo(p.x, p.y);
            });

            ctx.stroke();

            div.appendChild(c);
        }

        canvas.appendChild(div);
    });
}

/* ---------------- INIT ---------------- */
loadNote();
</script>

</body>
</html>