<?php
require_once "../api/db_connect.php";

require('../vendor/fpdf/fpdf.php');

$id = $_GET['note_id'];

$sql = "SELECT * FROM Private_Notes WHERE private_notes_id=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();

$result = $stmt->get_result()->fetch_assoc();

$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial','B',16);
$pdf->MultiCell(0,10,$result['notes_name']);
$pdf->Output();
?>