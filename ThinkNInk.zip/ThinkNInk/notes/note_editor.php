<?php
session_start();
if (!isset($_SESSION["student_id"])) {
    header("Location: ../auth/login.php");
    exit();
}

$note_id = $_GET['note_id'] ?? null;
$course_id = $_GET['course_id'] ?? null;
?>

<!DOCTYPE html>
<html>
<head>
    <title>ThinkNInk Editor</title>
    <link rel="stylesheet" href="editor.css">
</head>

<body>

<div class="toolbar">
    <button onclick="goBack()">⬅ Back</button>

    <button onclick="addText()">Text</button>

    <select id="shapeSelect">
        <option value="rect">Square</option>
        <option value="circle">Circle</option>
        <option value="triangle">Triangle</option>
    </select>
    <button onclick="addShape()">Add Shape</button>

    <button onclick="enablePen()">Pen</button>
<button onclick="disablePen()">Select</button>

    <label class="file-btn">
        Add Image
        <input type="file" onchange="uploadImage(event)">
    </label>

    <button onclick="addPage()">Add Page</button>
    <button onclick="deletePage()">Delete Page</button>

    <button onclick="prevPage()">◀</button>
    <button onclick="nextPage()">▶</button>

    <button onclick="undo()">Undo</button>
    <button onclick="redo()">Redo</button>

    <button onclick="saveNote()">Save</button>
    <button onclick="exportPDF()">PDF</button>

    <button id="deleteBtn" onclick="deleteSelected()" style="display:none;background:#ff4d6d;">Delete</button>

</div>

<div id="canvas"></div>

<script>
const note_id = new URLSearchParams(window.location.search).get("note_id");
const course_id = new URLSearchParams(window.location.search).get("course_id");
</script>

<script src="../notes/editor.js"></script>

</body>
</html>