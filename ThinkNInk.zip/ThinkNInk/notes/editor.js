let doc = {
    pages: [{ elements: [] }],
    currentPage: 0
};

let history = [];
let redoStack = [];

let selected = null;
let drag = null;
let resize = null;

let mode = "select";

let pen = {
    drawing: false,
    path: []
};

const canvas = document.getElementById("canvas");

function disablePen() {
    mode = "select";
}

function page() {
    return doc.pages[doc.currentPage];
}

function exportPDF() {
    const printWindow = window.open('', '_blank');

    const html = `
        <html>
        <head>
            <title>Export Note</title>
            <style>
                body {
                    font-family: Arial;
                    background: white;
                }
                .page {
                    position: relative;
                    width: 100%;
                }
                .element {
                    position: absolute;
                }
                canvas {
                    max-width: 100%;
                }
            </style>
        </head>
        <body>
            ${document.getElementById("canvas").innerHTML}
        </body>
        </html>
    `;

    printWindow.document.write(html);
    printWindow.document.close();

    printWindow.onload = () => {
        printWindow.focus();
        printWindow.print();
        printWindow.close();
    };
}

/* ---------------- SAVE STATE ---------------- */

function saveState() {
    try {
        history.push(JSON.stringify(doc));
        redoStack = [];

        // prevent memory explosion (keeps last 50 states only)
        if (history.length > 50) {
            history.shift();
        }
    } catch (err) {
        console.error("saveState error:", err);
    }
}

/* ---------------- BACK ---------------- */

function goBack() {
    const params = new URLSearchParams(window.location.search);
    const courseId = params.get("course_id");

    if (courseId) {
        window.location.href = `/ThinkNInk/classes/classes.php?course_id=${courseId}`;
    } else {
        window.location.href = "/ThinkNInk/classes/classes.php";
    }
}

/* ---------------- PAGES ---------------- */

function addPage() {
    doc.pages.push({ elements: [] });
    doc.currentPage = doc.pages.length - 1;
    render();
}

function deletePage() {
    if (doc.pages.length > 1) {
        doc.pages.splice(doc.currentPage, 1);
        doc.currentPage = 0;
        render();
    }
}

function nextPage() {
    if (doc.currentPage < doc.pages.length - 1) {
        doc.currentPage++;
        render();
    }
}

function prevPage() {
    if (doc.currentPage > 0) {
        doc.currentPage--;
        render();
    }
}

/* ---------------- ELEMENTS ---------------- */

function addText() {
    page().elements.push({
        id: Date.now(),
        type: "text",
        x: 200,
        y: 200,
        w: 160,
        h: 40,
        text: "Double click to edit"
    });

    saveState();
    render();
}

function addShape() {
    const type = document.getElementById("shapeSelect").value;

    page().elements.push({
        id: Date.now(),
        type: "shape",
        shape: type,
        x: 200,
        y: 200,
        w: 120,
        h: 120
    });

    saveState();
    render();
}

function uploadImage(e) {
    const file = e.target.files[0];
    if (!file) return;

    const reader = new FileReader();

    reader.onload = function () {
        const img = new Image();

        img.onload = function () {
            const canvas = document.createElement("canvas");
            const maxW = 800;

            const scale = Math.min(1, maxW / img.width);

            canvas.width = img.width * scale;
            canvas.height = img.height * scale;

            const ctx = canvas.getContext("2d");
            ctx.drawImage(img, 0, 0, canvas.width, canvas.height);

            const compressed = canvas.toDataURL("image/jpeg", 0.7);

            page().elements.push({
                id: Date.now(),
                type: "image",
                x: 200,
                y: 200,
                w: 200,
                h: 200,
                src: compressed
            });

            saveState();
            render();
        };

        img.src = reader.result;
    };

    reader.readAsDataURL(file);
    e.target.value = "";
}

/* ---------------- SELECT ---------------- */

function select(el, dom) {
    selected = el;

    document.querySelectorAll(".selected").forEach(e => e.classList.remove("selected"));
    dom.classList.add("selected");

    document.getElementById("deleteBtn").style.display = "inline-block";
}

/* ---------------- DELETE ---------------- */

function deleteSelected() {
    const p = page();
    p.elements = p.elements.filter(e => e !== selected);

    selected = null;
    document.getElementById("deleteBtn").style.display = "none";

    saveState();
    render();
}

/* ---------------- DRAG ---------------- */

document.addEventListener("mousemove", (e) => {
    if (drag) {
        drag.el.x = e.clientX - drag.offsetX;
        drag.el.y = e.clientY - drag.offsetY;
        render();
    }

    if (resize) {
        resize.el.w = Math.max(30, e.clientX - resize.startX);
        resize.el.h = Math.max(30, e.clientY - resize.startY);
        render();
    }
});

document.addEventListener("mouseup", () => {
    if (drag || resize) saveState();

    drag = null;
    resize = null;
});

/* ---------------- PEN ---------------- */

function enablePen() {
    mode = "pen";
    selected = null;
    document.getElementById("deleteBtn").style.display = "none";
}


canvas.addEventListener("mousedown", (e) => {
    if (mode !== "pen") return;

    pen.drawing = true;
    pen.path = [{ x: e.offsetX, y: e.offsetY }];
});

canvas.addEventListener("mousemove", (e) => {
    if (mode !== "pen") return;
    if (!pen.drawing) return;

    pen.path.push({ x: e.offsetX, y: e.offsetY });
    render();
});

canvas.addEventListener("mouseup", () => {
    if (mode !== "pen") return;
    if (!pen.drawing) return;

    page().elements.push({
        id: Date.now(),
        type: "pen",
        path: [...pen.path]
    });

    pen.drawing = false;

    saveState();
    render();
});

/* ---------------- RESIZE HANDLE ---------------- */

function startResize(e, el) {
    e.stopPropagation();

    resize = {
        el,
        startX: el.x + el.w,
        startY: el.y + el.h
    };
}

/* ---------------- RENDER ---------------- */

function render() {
    canvas.innerHTML = "";

    const pageEl = document.createElement("div");
    pageEl.className = "page";
    canvas.appendChild(pageEl);

selected = selected; // forces stable reference across rerenders

    page().elements.forEach(el => {
        const div = document.createElement("div");
        div.className = "element";

        div.style.left = el.x + "px";
        div.style.top = el.y + "px";

        /* SELECT */
        div.onclick = (e) => {
    if (mode === "pen") return; //  prevents pen interference

    e.stopPropagation();
    select(el, div);
};

        /* DRAG */
div.onmousedown = (e) => {
    if (mode === "pen") return;
    if (!selected || selected !== el) return;

    if (e.target.classList.contains("handle")) return;

    drag = {
        el,
        offsetX: e.clientX - el.x,
        offsetY: e.clientY - el.y
    };
};

        /* TEXT */
        if (el.type === "text") {
            div.classList.add("textbox");
            div.contentEditable = true;
            div.innerText = el.text;

            div.oninput = () => el.text = div.innerText;
        }

        /* SHAPE */
        if (el.type === "shape") {
            div.classList.add("shape");
            div.style.width = el.w + "px";
            div.style.height = el.h + "px";

            if (el.shape === "rect") div.style.background = "#b98aff";

            if (el.shape === "circle") {
                div.style.borderRadius = "50%";
                div.style.background = "#b98aff";
            }

            if (el.shape === "triangle") {
                div.style.width = "0";
                div.style.height = "0";
                div.style.borderLeft = `${el.w/2}px solid transparent`;
                div.style.borderRight = `${el.w/2}px solid transparent`;
                div.style.borderBottom = `${el.h}px solid #b98aff`;
                div.background = "transparent";
            }
        }

        /* IMAGE */
        if (el.type === "image") {
            const img = document.createElement("img");
            img.src = el.src;
            img.style.width = el.w + "px";
            img.style.height = el.h + "px";
            img.className = "image";
            div.appendChild(img);
        }

        /* PEN */
        if (el.type === "pen") {
            const c = document.createElement("canvas");
            c.width = 2000;
            c.height = 2000;

            const ctx = c.getContext("2d");

            ctx.beginPath();
            el.path.forEach((p, i) => {
                if (i === 0) ctx.moveTo(p.x, p.y);
                else ctx.lineTo(p.x, p.y);
            });

            ctx.stroke();

            div.appendChild(c);
        }

        /* RESIZE HANDLE */
        if (selected === el) {
            const handle = document.createElement("div");
            handle.className = "handle";

            handle.onmousedown = (e) => startResize(e, el);

            div.appendChild(handle);
        }

        pageEl.appendChild(div);
    });

    /* LIVE PEN */
    if (pen.drawing) {
        const live = document.createElement("canvas");
        live.width = 2000;
        live.height = 2000;

        const ctx = live.getContext("2d");

        ctx.beginPath();
        pen.path.forEach((p, i) => {
            if (i === 0) ctx.moveTo(p.x, p.y);
            else ctx.lineTo(p.x, p.y);
        });

        ctx.stroke();

        pageEl.appendChild(live);
    }
    if (selected) {
    const found = page().elements.find(e => e.id === selected.id);
    if (found) selected = found;
}
}

/* ---------------- SAVE FIX ---------------- */
function saveNote() {
    console.log("SAVE CLICKED");

    fetch("/ThinkNInk/api/notes/update.php", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            note_id: note_id,
            content: JSON.stringify(doc)
        })
    })
    .then(res => res.text()) // 
    .then(text => {
        console.log("RAW SERVER RESPONSE:");
        console.log(text);   // 
        alert("Saved!");
    })
    .catch(err => {
        console.error("FETCH ERROR:", err);
    });
}
/* ---------------- LOAD ---------------- */

async function loadNote() {
    if (!note_id) return;

    const res = await fetch(`/ThinkNInk/api/notes/get.php?id=${note_id}`);
    const data = await res.json();

    if (data && data.content) {
        try {
            doc = JSON.parse(data.content);
        } catch (e) {
            console.error("Parse failed, resetting doc");
            doc = { pages: [{ elements: [] }], currentPage: 0 };
        }
    }

    render();
}

/* ---------------- UNDO REDO ---------------- */

function undo() {
    if (history.length === 0) return;

    try {
        redoStack.push(JSON.stringify(doc));
        doc = JSON.parse(history.pop());
        render();
    } catch (err) {
        console.error("undo error:", err);
    }
}

function redo() {
    if (redoStack.length === 0) return;

    try {
        history.push(JSON.stringify(doc));
        doc = JSON.parse(redoStack.pop());
        render();
    } catch (err) {
        console.error("redo error:", err);
    }
}

/* INIT */
window.onload = () => {
    loadNote();
    render();
};