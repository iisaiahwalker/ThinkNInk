<?php
declare(strict_types=1);
session_start();

if (!isset($_SESSION["student_id"])) {
    header("Location: ../auth/login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Notes Dashboard</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="dashboard.css">
</head>
<body>

    <div class="dashboard-container">
        <header class="dashboard-header">
            <div class="dashboard-header-top">
                <div class="dashboard-title">
                    <h1>Dashboard</h1>
                    <p>Welcome back. Select a class to open your notes.</p>
                </div>
                <a href="../auth/logout.php" class="log-out-link">Logout</a>
            </div>
        </header>

        <main class="canvas-grid" id="coursesContainer"></main>

<script>
async function loadCourses() {
    const res = await fetch("/ThinkNInk/api/courses/get_courses.php");
    const courses = await res.json();

    const container = document.getElementById("coursesContainer");
    container.innerHTML = "";

    if (courses.length === 0) {
        container.innerHTML = "<p>No classes found</p>";
        return;
    }

    courses.forEach(c => {
        container.innerHTML += `
            <a href="/ThinkNInk/classes/classes.php?course_id=${c.course_id}" class="canvas-card">
                <h2>${c.course_name}</h2>
                <p>Section: ${c.section_number}</p>
                <span>Open class</span>
            </a>
        `;
    });
}

loadCourses();
</script>
    </div>

</body>
</html>
