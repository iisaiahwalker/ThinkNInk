<?php
session_start();
include("../db_connect.php");

$data = json_decode(file_get_contents("php://input"), true);

$private_notes_id = $data["note_id"];
$student_id = $_SESSION["student_id"];

/* get original note */
$stmt = $conn->prepare("
    SELECT * 
    FROM Private_Notes 
    WHERE private_notes_id = ?
");
$stmt->bind_param("i", $private_notes_id);
$stmt->execute();

$note = $stmt->get_result()->fetch_assoc();

/* insert into PRIVATE NOTES */
$insert = $conn->prepare("
    INSERT INTO Private_Notes
    (notes_name, student_id, course_id, chapter, topic, content)
    VALUES (?, ?, ?, ?, ?, ?)
");

$insert->bind_param(
    "ssssss",
    $note["notes_name"],
    $student_id,
    $note["course_id"],
    $note["chapter"],
    $note["topic"],
    $note["content"]
);

$insert->execute();

echo json_encode(["success" => true]);
?>