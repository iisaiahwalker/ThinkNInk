<?php
require_once "../db_connect.php";

$data = json_decode(file_get_contents("php://input"), true);

$sql = "UPDATE Private_Notes SET content=? WHERE private_notes_id=?";
$stmt = $conn->prepare($sql);

$stmt->bind_param("si",
    $data['content'],
    $data['note_id']
);

echo json_encode(["success" => $stmt->execute()]);
?>