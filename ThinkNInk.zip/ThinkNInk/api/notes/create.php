<?php
require_once "../db_connect.php";
session_start();

$data = json_decode(file_get_contents("php://input"), true);

$student_id = $_SESSION['student_id'];

$notes_name = $data['notes_name'];
$course_id = $data['course_id'];
$chapter = $data['chapter'] ?? "";
$topic = $data['topic'] ?? "";

// empty canvas JSON
$content = json_encode([
    "pages" => [
        ["elements" => []]
    ],
    "currentPage" => 0
]);

$stmt = $conn->prepare("
    INSERT INTO Private_Notes
    (notes_name, student_id, course_id, chapter, topic, content)
    VALUES (?, ?, ?, ?, ?, ?)
");

$stmt->bind_param(
    "ssssss",
    $notes_name,
    $student_id,
    $course_id,
    $chapter,
    $topic,
    $content
);

$stmt->execute();

echo json_encode([
    "success" => true,
    "note_id" => $stmt->insert_id
]);
?>