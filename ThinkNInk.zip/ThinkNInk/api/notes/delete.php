<?php
require_once "../db_connect.php";
session_start();

$data = json_decode(file_get_contents("php://input"), true);

$note_id = $data['note_id'];
$student_id = $_SESSION['student_id'];

// ensure user owns note
$stmt = $conn->prepare("
    DELETE FROM Private_Notes
    WHERE private_notes_id=? AND student_id=?
");

$stmt->bind_param("is", $note_id, $student_id);

echo json_encode([
    "success" => $stmt->execute()
]);
?>