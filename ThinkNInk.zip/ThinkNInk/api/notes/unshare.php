<?php
require_once "../db_connect.php";
session_start();

$data = json_decode(file_get_contents("php://input"), true);

$note_id = $data["note_id"];
$student_id = $_SESSION["student_id"];

$stmt = $conn->prepare("
DELETE FROM Class_Notes 
WHERE private_notes_id = ? AND student_id = ?
");

$stmt->bind_param("is", $note_id, $student_id);
$stmt->execute();

echo json_encode(["success" => true]);

$stmt = $conn->prepare("
    DELETE FROM Class_Notes
    WHERE private_notes_id = ?
    AND student_id = ?
");

$stmt->bind_param("is", $private_notes_id, $student_id);
$stmt->execute();

echo json_encode(["success" => true]);