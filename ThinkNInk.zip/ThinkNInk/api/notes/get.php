<?php
require_once "../db_connect.php";
session_start();

// get note ID from URL
$id = $_GET['id'];

// get logged-in user
$student_id = $_SESSION['student_id'];

// secure query (only fetch user's own note)
$stmt = $conn->prepare("
    SELECT * FROM Private_Notes
    WHERE private_notes_id=? AND student_id=?
");

$stmt->bind_param("is", $id, $student_id);
$stmt->execute();

$result = $stmt->get_result();

// return data as JSON
if ($result->num_rows > 0) {
    echo json_encode($result->fetch_assoc());
} else {
    echo json_encode(["error" => "Note not found"]);
}
?>