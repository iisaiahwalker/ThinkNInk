<?php
require_once "../db_connect.php";
session_start();

if (!isset($_SESSION['student_id'])) {
    echo json_encode([]);
    exit();
}

$student_id = $_SESSION['student_id'];

$stmt = $conn->prepare("
    SELECT 
        c.course_id,
        c.course_name,
        c.section_number,
        c.semester
    FROM Enrollment e
    JOIN Courses c ON e.course_id = c.course_id
    WHERE e.student_id = ?
");

$stmt->bind_param("s", $student_id);
$stmt->execute();

$result = $stmt->get_result();

$courses = [];

while ($row = $result->fetch_assoc()) {
    $courses[] = $row;
}

echo json_encode($courses);
?>