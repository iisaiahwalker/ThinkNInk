<?php
require_once "../db_connect.php";

$id = $_GET['id'];

$sql = "DELETE FROM Tests WHERE test_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);

echo json_encode(["success" => $stmt->execute()]);
?>