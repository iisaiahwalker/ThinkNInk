<?php
require_once "../db_connect.php";

$data = json_decode(file_get_contents("php://input"), true);

$course_id = $data['course_id']; 
$chapter   = $data['chapter'] ?? '';
$topic     = $data['topic'] ?? '';

$sql = "SELECT * FROM Private_Notes WHERE course_id = ?";
$params = [$course_id];
$types = "s";

/*
ONLY FILTER USING:
- chapter
- topic
- content
*/

if (!empty($chapter)) {
    $sql .= " AND (chapter LIKE ? OR content LIKE ?)";
    $like = "%$chapter%";
    $params[] = $like;
    $params[] = $like;
    $types .= "ss";
}

if (!empty($topic)) {
    $sql .= " AND (topic LIKE ? OR content LIKE ?)";
    $like = "%$topic%";
    $params[] = $like;
    $params[] = $like;
    $types .= "ss";
}

$stmt = $conn->prepare($sql);
$stmt->bind_param($types, ...$params);
$stmt->execute();

$result = $stmt->get_result();

$notes = [];

while ($row = $result->fetch_assoc()) {

    $doc = json_decode($row["content"], true);

   
    if ($doc && isset($doc["pages"])) {

        foreach ($doc["pages"] as $page) {

            $pageText = "";

            if (isset($page["elements"])) {
                foreach ($page["elements"] as $el) {
                    if ($el["type"] === "text" && isset($el["text"])) {
                        $pageText .= " " . strtolower($el["text"]);
                    }
                }
            }

            $includePage = false;

            
            if (!empty($topic) && stripos($row["topic"], $topic) !== false) {
                $includePage = true;
            }

           
            if (!empty($chapter) && stripos($row["chapter"], $chapter) !== false) {
                $includePage = true;
            }

            
            if (!empty($topic) && stripos($pageText, strtolower($topic)) !== false) {
                $includePage = true;
            }

            if ($includePage) {
                $notes[] = [
                    "notes_name" => $row["notes_name"],
                    "chapter"    => $row["chapter"],
                    "topic"      => $row["topic"],

                    
                    "content" => json_encode([
                        "pages" => [$page],
                        "currentPage" => 0
                    ])
                ];
            }
        }

    } else {
        // fallback if JSON fails
        $notes[] = $row;
    }
}

echo json_encode($notes);
?>