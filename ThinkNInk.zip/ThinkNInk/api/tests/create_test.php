<?php
require_once "../db_connect.php";

$data = json_decode(file_get_contents("php://input"), true);

$sql = "INSERT INTO Tests (course_id, test_name, chapter, topic)
        VALUES (?, ?, ?, ?)";

$stmt = $conn->prepare($sql);
$stmt->bind_param(
    "ssss",
    $data['course_id'],
    $data['test_name'],
    $data['chapter'],
    $data['topic']
);

echo json_encode([
    "success" => $stmt->execute(),
    "test_id" => $stmt->insert_id
]);
?>