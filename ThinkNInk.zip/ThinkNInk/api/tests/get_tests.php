<?php
require_once "../db_connect.php";

$course_id = $_GET['course_id'];

$sql = "SELECT * FROM Tests WHERE course_id = ? ORDER BY test_id DESC";

$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $course_id);
$stmt->execute();

$result = $stmt->get_result();

$tests = [];
while ($row = $result->fetch_assoc()) {
    $tests[] = $row;
}

echo json_encode($tests);
?>