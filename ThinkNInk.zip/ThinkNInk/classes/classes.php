<?php
session_start();

if (!isset($_SESSION["student_id"])) {
    header("Location: ../auth/login.php");
    exit();
}

$firstName = $_SESSION['first_name'] ?? 'Student';
$course_id = $_GET['course_id'] ?? "";
?>

<!DOCTYPE html>
<html>
<head>
    <title>Class</title>
    <link rel="stylesheet" href="classes.css">
</head>

<body>

<script>
const CURRENT_COURSE = "<?php echo $course_id; ?>";
</script>

<div class="app-container">

<!-- SIDEBAR -->
<aside class="sidebar">
    <div class="logo">ThinkNInk</div>

    <nav class="nav-menu">
        <a href="../dashboard/dashboard.php" class="nav-item">All Classes</a>

        <a href="#" class="nav-item" onclick="showPanel('privatePanel'); loadNotes()">Private Notes</a>

        <a href="#" class="nav-item" onclick="showPanel('sharedPanel'); loadShared()">Shared Notes</a>

        <a href="#" class="nav-item" onclick="showPanel('testPanel')">Study Guides</a>
    </nav>

    <div class="sidebar-footer">
        <a href="../auth/logout.php" class="log-out-link">Log out</a>
    </div>
</aside>

<!-- MAIN -->
<main class="main-content">

<header class="topbar">
    <h1>Welcome <?php echo $firstName; ?></h1>
    <button class="new-note-btn" onclick="openModal()">+ New Note</button>
</header>

<!-- PRIVATE -->
<section id="privatePanel" class="canvas-area"></section>

<!-- SHARED -->
<section id="sharedPanel" class="canvas-area" style="display:none;"></section>

<!-- TEST -->
<!-- TEST -->
<section id="testPanel" style="display:none; padding:15px; height:100%; overflow:hidden;">

    <h2 style="margin-bottom:10px;">Study Guides</h2>

    <!-- CONTROLS -->
    <div id="testControls" style="display:flex; gap:10px; flex-wrap:wrap; margin-bottom:15px;">
        <input id="testName" placeholder="Test Name">
        <input id="chapter" placeholder="Chapter">
        <input id="topic" placeholder="Topic">

        <button class="action-btn" onclick="createTest()">Create Test</button>
        <button class="action-btn" onclick="smartFilterNotes()">Find Notes</button>
        <button class="action-btn" onclick="backToTests()">Back to Tests</button>
    </div>

    <!-- FILTER RESULTS -->
<div id="filteredResults" style="display:none;"></div>
<div id="testList" class="test-grid"></div>

</section>

</main>
</div>

<script>

    let flashcards = [];
let currentCard = 0;

async function openTestViewer(testName, chapter, topic) {

    document.getElementById("testViewerModal").style.display = "flex";

    document.getElementById("tvTitle").innerText = testName;
    document.getElementById("tvMeta").innerText = `Chapter: ${chapter || "—"} | Topic: ${topic || "—"}`;

    const res = await fetch("/ThinkNInk/api/tests/smart_filter_notes.php", {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({
            course_id: CURRENT_COURSE,
            chapter: chapter,
            topic: topic
        })
    });

    flashcards = await res.json();
    currentCard = 0;

    renderCard();
}

function renderCard() {
    const box = document.getElementById("flashcardBox");
    box.innerHTML = "";

    if (!flashcards.length) {
        box.innerHTML = "No notes found for this test.";
        document.getElementById("cardIndex").innerText = "";
        return;
    }

    const note = flashcards[currentCard];

    // title/meta still shown outside if you want
    document.getElementById("cardIndex").innerText =
        `${currentCard + 1} / ${flashcards.length}`;

    // create preview canvas
    const preview = document.createElement("div");
    preview.style.position = "relative";
    preview.style.width = "100%";
    preview.style.height = "300px";
    preview.style.overflow = "hidden";
    preview.style.borderRadius = "12px";
    preview.style.background = "#fff";

    let doc = null;

    try {
        doc = JSON.parse(note.content);
    } catch (e) {
        preview.innerHTML = `
            <div style="padding:10px;">
                ${note.content || "No content available"}
            </div>
        `;
        box.appendChild(preview);
        return;
    }

    if (!doc?.pages?.length) {
        preview.innerHTML = "Empty note";
        box.appendChild(preview);
        return;
    }

    const page = doc.pages[doc.currentPage || 0];

 page.elements.forEach(el => {

    const scale = 0.6;

    // base container
    const elDiv = document.createElement("div");
    elDiv.style.position = "absolute";
    elDiv.style.left = (el.x * scale) + "px";
    elDiv.style.top = (el.y * scale) + "px";

    /*
    =====================
    TEXT
    =====================
    */
    if (el.type === "text") {
        elDiv.innerText = el.text;
        elDiv.style.fontSize = "12px";
        elDiv.style.color = "#2a1748";
        elDiv.style.maxWidth = "200px";
        elDiv.style.whiteSpace = "pre-wrap";
    }

    /*
    =====================
    SHAPES
    =====================
    */
    if (el.type === "shape") {

        elDiv.style.width = (el.w * scale) + "px";
        elDiv.style.height = (el.h * scale) + "px";

        // rectangle default
        elDiv.style.background = "#b98aff";

        // circle
        if (el.shape === "circle") {
            elDiv.style.borderRadius = "50%";
        }

        // triangle
        if (el.shape === "triangle") {
            elDiv.style.width = "0";
            elDiv.style.height = "0";
            elDiv.style.borderLeft = (el.w * scale / 2) + "px solid transparent";
            elDiv.style.borderRight = (el.w * scale / 2) + "px solid transparent";
            elDiv.style.borderBottom = (el.h * scale) + "px solid #b98aff";
            elDiv.style.background = "transparent";
        }

        
        if (el.text) {
            const textDiv = document.createElement("div");
            textDiv.innerText = el.text;

            textDiv.style.position = "absolute";
            textDiv.style.top = "50%";
            textDiv.style.left = "50%";
            textDiv.style.transform = "translate(-50%, -50%)";
            textDiv.style.fontSize = "12px";
            textDiv.style.color = "#fff";
            textDiv.style.textAlign = "center";

            elDiv.appendChild(textDiv);
        }
    }

    /*
    =====================
    IMAGES
    =====================
    */
    if (el.type === "image") {
        const img = document.createElement("img");
        img.src = el.src;

        img.style.width = (el.w * scale) + "px";
        img.style.height = (el.h * scale) + "px";
        img.style.objectFit = "cover";

        elDiv.appendChild(img);
    }

/*
=====================
PEN DRAWING (ROBUST FIX)
=====================
*/
if (el.type === "pen") {

    // create canvas
    const canvas = document.createElement("canvas");
    const ctx = canvas.getContext("2d");

    const scale = 0.6;

    canvas.width = 300;
    canvas.height = 300;

    canvas.style.position = "absolute";
    canvas.style.left = (el.x * scale) + "px";
    canvas.style.top = (el.y * scale) + "px";
    canvas.style.width = "300px";
    canvas.style.height = "300px";
    canvas.style.borderRadius = "8px";

    ctx.strokeStyle = "#2a1748";
    ctx.lineWidth = 2;
    ctx.lineJoin = "round";
    ctx.lineCap = "round";

    ctx.beginPath();

    
    let points = [];

    if (Array.isArray(el.points)) {
        points = el.points;
    } 
    else if (Array.isArray(el.path)) {
        points = el.path;
    } 
    else if (Array.isArray(el.stroke)) {
        points = el.stroke;
    } 
    else if (typeof el.data === "string") {
        try {
            const parsed = JSON.parse(el.data);
            points = parsed.points || parsed.path || parsed.stroke || [];
        } catch (e) {
            points = [];
        }
    }

    // nothing to draw
    if (!points.length) return;

    // draw stroke
    points.forEach((p, i) => {

        const x = (p.x ?? p[0] ?? 0) * scale;
        const y = (p.y ?? p[1] ?? 0) * scale;

        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
    });

    ctx.stroke();

    preview.appendChild(canvas);
    return;
}
    preview.appendChild(elDiv);
});

    box.appendChild(preview);
}

function nextCard() {
    if (currentCard < flashcards.length - 1) {
        currentCard++;
        renderCard();
    }
}

function prevCard() {
    if (currentCard > 0) {
        currentCard--;
        renderCard();
    }
}

function closeTestViewer() {
    document.getElementById("testViewerModal").style.display = "none";
}

async function deleteTest(id) {
    await fetch(`/ThinkNInk/api/tests/delete_test.php?id=${id}`);
    loadTests();
}

function resetStudyView() {
    document.getElementById("filteredResults").innerHTML = "";
}

// PANEL SWITCH
function showPanel(panel) {
    const panels = ["privatePanel", "sharedPanel", "testPanel"];

    panels.forEach(p => {
        document.getElementById(p).style.display = "none";
    });

    const active = document.getElementById(panel);

    // IMPORTANT: keep layout consistency
    if (panel === "testPanel") {
        active.style.display = "flex";
    } else {
        active.style.display = "block";
    }

    if (panel === "privatePanel") loadNotes();
    if (panel === "sharedPanel") loadShared();

    if (panel === "testPanel") {
        resetStudyView();
        loadTests();
    }
}
async function loadTests() {
    const res = await fetch(`/ThinkNInk/api/tests/get_tests.php?course_id=${CURRENT_COURSE}`);
    const tests = await res.json();

    let html = "";

    tests.forEach(t => {
        html += `
        <div class="card">
            <div class="card-header">
                <h2>${t.test_name}</h2>

                <div class="card-actions">
                    <button class="action-btn edit-note"
                        onclick="openTestViewer('${t.test_name}','${t.chapter}','${t.topic}')">
                        View
                    </button>

                    <button class="action-btn delete-note"
                        onclick="deleteTest(${t.test_id})">
                        Delete
                    </button>
                </div>
            </div>

            <p><b>Chapter:</b> ${t.chapter || ""}</p>
            <p><b>Topic:</b> ${t.topic || ""}</p>
        </div>`;
    });

    
    document.getElementById("testList").innerHTML = html;
}

// LOAD PRIVATE NOTES
async function loadNotes() {
    const res = await fetch(`/ThinkNInk/api/notes/get_all.php?course_id=${CURRENT_COURSE}`);
    const notes = await res.json();


    let html = "";

    notes.forEach(n => {

        const isShared = n.class_notes_id !== null;

        html += `
        <div class="card">
            <div class="card-header">
                <h2>${n.notes_name}</h2>

                <div class="card-actions">
                    <button class="action-btn edit-note" onclick="openNote(${n.private_notes_id})">
                        Open
                    </button>

                    <button class="action-btn delete-note" onclick="deleteNote(${n.private_notes_id})">
                        Delete
                    </button>

                    ${
                        isShared
                        ? `<button class="action-btn delete-note" onclick="unshareNote(${n.private_notes_id})">
                                Unshare
                           </button>`
                        : `<button class="action-btn" onclick="shareNote(${n.private_notes_id})">
                                Share
                           </button>`
                    }
                </div>
            </div>

            <p>${n.chapter || ""} ${n.topic || ""}</p>
        </div>
        `;
    });

    document.getElementById("privatePanel").innerHTML = html;
}

// SHARED NOTES
async function loadShared() {
    const res = await fetch(`/ThinkNInk/api/notes/get_shared.php?course_id=${CURRENT_COURSE}`);
    const notes = await res.json();

    let html = "";

    notes.forEach(n => {
html += `
<div class="card">
    <h2>${n.notes_name}</h2>

    <p>Chapter: ${n.chapter || ""}</p>
    <p>Topic: ${n.topic || ""}</p>

    <small>Shared by: ${n.first_name} ${n.last_name}</small>

    <div class="card-actions">
        <button class="action-btn edit-note" onclick="viewShared(${n.private_notes_id})">
            View
        </button>

        <button class="action-btn" onclick="copyNote(${n.private_notes_id})">
            Copy
        </button>
    </div>
</div>`;
    });

    document.getElementById("sharedPanel").innerHTML = html;
}
function viewShared(id) {
    const course = CURRENT_COURSE;
    window.location.href = `/ThinkNInk/notes/notes_snapshot.php?note_id=${id}&course_id=${course}`;
}

// BUTTON FUNCTIONS
function openNote(id) {
    window.location.href = `/ThinkNInk/notes/note_editor.php?note_id=${id}&course_id=${CURRENT_COURSE}`;
}

function deleteNote(id) {
    fetch("/ThinkNInk/api/notes/delete.php", {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({note_id: id})
    }).then(() => loadNotes());
}

async function shareNote(id) {
    await fetch("/ThinkNInk/api/notes/share.php", {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({ note_id: id })
    });

    loadNotes(); // refresh UI
}

async function unshareNote(id) {
    await fetch("/ThinkNInk/api/notes/unshare.php", {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({ note_id: id })
    });

    loadNotes(); // refresh UI
}

function copyNote(id) {
    fetch("/ThinkNInk/api/notes/copy_shared.php", {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({note_id: id})
    }).then(() => alert("Copied to your notes"));
}

// MODAL
function openModal() {
    console.log("OPEN MODAL CLICKED"); // debug check
    document.getElementById("noteModal").style.display = "flex";
}

function closeModal() {
    document.getElementById("noteModal").style.display = "none";
}

function submitNote() {
    fetch("/ThinkNInk/api/notes/create.php", {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({
            notes_name: document.getElementById("noteTitle").value,
            chapter: document.getElementById("noteChapter").value,
            topic: document.getElementById("noteTopic").value,
            course_id: CURRENT_COURSE
        })
    })
    .then(async res => {
        const text = await res.text();
        console.log("RAW RESPONSE:", text); // IMPORTANT DEBUG
        return JSON.parse(text);
    })
    .then(data => {
        if (data.error) {
            alert(data.error);
            return;
        }

        closeModal();
        loadNotes(); // refresh list
    })
    .catch(err => {
        console.error("CREATE NOTE ERROR:", err);
    });
}

// TEST
async function createTest() {
    await fetch("/ThinkNInk/api/tests/create_test.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
            course_id: CURRENT_COURSE,
            test_name: document.getElementById("testName").value,
            chapter: document.getElementById("chapter").value,
            topic: document.getElementById("topic").value
        })
    });

    // clear inputs (nice UX)
    document.getElementById("testName").value = "";
    document.getElementById("chapter").value = "";
    document.getElementById("topic").value = "";

    // refresh list immediately
    loadTests();
}

window.smartFilterNotes = async function () {
    const res = await fetch("/ThinkNInk/api/tests/smart_filter_notes.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
            course_id: CURRENT_COURSE,
            chapter: document.getElementById("chapter").value,
            topic: document.getElementById("topic").value
        })
    });

    const notes = await res.json();

    let html = "";

    notes.forEach(n => {
        html += `
        <div class="card">
            <div class="card-header">
                <h2>${n.notes_name}</h2>
            </div>

            <p><b>Chapter:</b> ${n.chapter || "—"}</p>
            <p><b>Topic:</b> ${n.topic || "—"}</p>

 ${renderHumanReadablePreview(n)}
        </div>`;
    });

    // 🔥 SWITCH MODES CLEANLY
    document.getElementById("testList").style.display = "none";
    document.getElementById("filteredResults").style.display = "block";
    document.getElementById("filteredResults").innerHTML = html;
};

function backToTests() {
    document.getElementById("filteredResults").innerHTML = "";
    document.getElementById("filteredResults").style.display = "none";
    document.getElementById("testList").style.display = "grid";
}

function renderHumanReadablePreview(note) {

    let doc = null;

    try {
        doc = JSON.parse(note.content);
    } catch (e) {
        return `<div style="
            padding:10px;
            font-size:0.9rem;
            color:#3b2a5c;
        ">
            ${note.content || "No content available"}
        </div>`;
    }

    if (!doc?.pages?.length) {
        return `<div style="padding:10px;">Empty note</div>`;
    }

    const page = doc.pages[doc.currentPage || 0];

    let textBlocks = [];
    let shapeCount = 0;
    let penCount = 0;
    let imageCount = 0;

    page.elements.forEach(el => {

        if (el.type === "text") {
            if (el.text?.trim()) {
                textBlocks.push(el.text.trim());
            }
        }

        if (el.type === "shape") shapeCount++;
        if (el.type === "pen") penCount++;
        if (el.type === "image") imageCount++;
    });

    let shapeSummary = "";
    if (shapeCount > 0) shapeSummary += `🟣 Shapes: ${shapeCount} `;
    if (penCount > 0) shapeSummary += `✏️ Drawings: ${penCount} `;
    if (imageCount > 0) shapeSummary += `🖼 Images: ${imageCount}`;

    return `
        <div style="
            padding:10px;
            border-radius:10px;
            background:#f8f4ff;
            border:1px solid #e2d4ff;
            max-height:180px;
            overflow:auto;
        ">

            ${textBlocks.length
                ? `<div style="margin-bottom:8px; font-weight:600;">
                        ${textBlocks.join("<br>")}
                   </div>`
                : `<div style="color:#888;">No text found</div>`
            }

            <div style="font-size:0.8rem; color:#6b4aa5; margin-top:8px;">
                ${shapeSummary || "No visual elements"}
            </div>

        </div>
    `;
}

// INIT
window.onload = () => {
    showPanel("privatePanel");
    loadNotes();
    loadTests(); // <-- ADD THIS
    document.getElementById("noteModal").style.display = "none";
};
</script>
<div id="noteModal" class="modal">
  <div class="modal-content">
    <h2>Create Note</h2>

    <input id="noteTitle" placeholder="Title">
    <input id="noteChapter" placeholder="Chapter">
    <input id="noteTopic" placeholder="Topic">

    <button class="action-btn" onclick="submitNote()">Create</button>
    <button class="action-btn delete-note" onclick="closeModal()">Cancel</button>
  </div>
</div>
<div id="testViewerModal" class="modal">
  <div class="modal-content" style="max-width:700px;">
    
    <h2 id="tvTitle"></h2>
    <p id="tvMeta"></p>

    <div id="flashcardBox" style="
        margin-top:15px;
        padding:15px;
        background:#f8f4ff;
        border-radius:12px;
        border:1px solid #e2d4ff;
        min-height:200px;
        white-space:pre-wrap;
    "></div>

    <div style="display:flex; justify-content:space-between; margin-top:15px;">
        <button class="action-btn" onclick="prevCard()">◀ Prev</button>
        <span id="cardIndex"></span>
        <button class="action-btn" onclick="nextCard()">Next ▶</button>
    </div>

    <button class="action-btn delete-note" onclick="closeTestViewer()" style="margin-top:15px;">
        Close
    </button>

  </div>
</div>
</body>
</html>
